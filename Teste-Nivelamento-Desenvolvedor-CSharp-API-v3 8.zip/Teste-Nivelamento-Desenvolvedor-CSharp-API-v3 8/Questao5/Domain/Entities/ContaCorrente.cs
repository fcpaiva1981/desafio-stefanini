namespace Questao5.Domain.Entities;

public class ContaCorrente
{
    public int Numero { get; set; }
    public string Nome { get; set; }
    public decimal Saldo { get; set; }
}