import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CpfConsultaComponent } from './pages/cpf-consulta/cpf-consulta.component';
import { CooperadoDetalheComponent } from './pages/cooperado-detalhe/cooperado-detalhe.component';

const routes: Routes = [
  { path: '', component: CpfConsultaComponent },
  { path: 'cooperado/:cpf', component: CooperadoDetalheComponent },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }