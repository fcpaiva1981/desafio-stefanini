import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { CpfConsultaComponent } from './pages/cpf-consulta/cpf-consulta.component';
import { CooperadoDetalheComponent } from './pages/cooperado-detalhe/cooperado-detalhe.component';

@NgModule({
  declarations: [
    AppComponent,
    CpfConsultaComponent,
    CooperadoDetalheComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }