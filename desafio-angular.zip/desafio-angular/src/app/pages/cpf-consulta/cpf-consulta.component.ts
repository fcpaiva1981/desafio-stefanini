import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-cpf-consulta',
  templateUrl: './cpf-consulta.component.html',
  styleUrls: ['./cpf-consulta.component.scss']
})
export class CpfConsultaComponent {
  form: FormGroup;
  erro: string = '';

  constructor(private fb: FormBuilder, private router: Router) {
    this.form = this.fb.group({
      cpf: ['', [Validators.required]]
    });
  }

  validarCpf(cpf: string): boolean {
    cpf = cpf.replace(/[^\d]+/g, '');
    if (cpf.length !== 11 || /^(\d)+$/.test(cpf)) return false;

    let soma = 0;
    for (let i = 0; i < 9; i++) soma += parseInt(cpf.charAt(i)) * (10 - i);
    let resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) resto = 0;
    if (resto !== parseInt(cpf.charAt(9))) return false;

    soma = 0;
    for (let i = 0; i < 10; i++) soma += parseInt(cpf.charAt(i)) * (11 - i);
    resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) resto = 0;
    return resto === parseInt(cpf.charAt(10));
  }

  onSubmit() {
    const cpf = this.form.value.cpf;
    if (this.validarCpf(cpf)) {
      this.erro = '';
      this.router.navigate(['/cooperado', cpf]);
    } else {
      this.erro = 'CPF inválido. Por favor, tente novamente.';
    }
  }
}