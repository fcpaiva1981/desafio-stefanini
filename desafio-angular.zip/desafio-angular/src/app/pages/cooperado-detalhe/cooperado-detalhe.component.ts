import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-cooperado-detalhe',
  templateUrl: './cooperado-detalhe.component.html',
  styleUrls: ['./cooperado-detalhe.component.scss']
})
export class CooperadoDetalheComponent implements OnInit {
  cpf: string | null = '';
  cooperado: any;

  constructor(private route: ActivatedRoute) {}

  ngOnInit() {
    this.cpf = this.route.snapshot.paramMap.get('cpf');
    this.cooperado = {
      nome: 'João da Silva',
      cpf: this.cpf,
      associadoDesde: '2015',
      status: 'Ativo'
    };
  }
}